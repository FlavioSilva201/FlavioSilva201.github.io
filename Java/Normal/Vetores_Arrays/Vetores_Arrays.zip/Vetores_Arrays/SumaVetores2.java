public class SumaVetores{
	public static void main(String[] args) {
		int conta=Integer.parseInt(args[0]);
		int soma=0;
		int multiplicacao=1;
		int subtracao=0;
		for (int count1=1;count1<args.length ;count1++ ) {
			if (conta==0) {
			soma+=Integer.parseInt(args[count1]);
			System.out.println(soma);
			} //End if
			else if (conta==1) {
				multiplicacao*=Integer.parseInt(args[count1]);
				System.out.println(multiplicacao);
			}//End elif
			else{
				subtracao-=Integer.parseInt(args[count1]);
				System.out.println(subtracao);
			} //End else
		}// end for
	} //End Method
}//End Class