public class VetoresDoAveco2{
	public static void main(String[] args) {

		int [] vetor = new int[] {1,2,3,4,5};
		int [] vetor2=new int [vetor.length];
		int count2=vetor.length-1;
		/*while (count<vetor.legth){
			
		}*/// end while
		for (int count=0;count<vetor.length;count++) {
			vetor2[count]=vetor[count2];
			count2--;
		}// end for
		for (int count3=0;count3<vetor.length ;count3++ ) {
			System.out.println(vetor[count3]);
		}
		System.out.println("---------");
		for (int count3=0;count3<vetor.length ;count3++ ) {
			System.out.println(vetor2[count3]);
		}
	}// end method
}//end class