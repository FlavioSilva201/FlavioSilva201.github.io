import java.util.Random;

public class Vetores{
	public static void main(String[] args) {

		int numDados =Integer.parseInt(args[0]);
		int[] valorDados = new int[numDados];
		Random rand = new Random();
		int valorMaior=0;
		int arrayMaior=0;

		for (int count1=0; count1<numDados; count1++ ) {
			valorDados[count1]=rand.nextInt(21)+1;
			System.out.println(valorDados[count1]);
		}//end for

		for (int count1=0; count1<numDados ;count1++ ) {
			if (valorMaior<valorDados[count1]){
				valorMaior=valorDados[count1];
				arrayMaior=count1;
			}//end if
		}//end for
		
		System.out.println("O valor maior é: "+valorMaior+" está na posição: "+arrayMaior);
	}// end method
}//end class