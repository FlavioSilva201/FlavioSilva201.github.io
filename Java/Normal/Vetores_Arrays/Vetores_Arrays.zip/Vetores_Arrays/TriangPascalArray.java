public class TriangPascalArray {
    public static void main(String[] args) {

    	int nLinhas=5;
    	int [][] matrix = new int[nLinhas][];

    	for (int count1=0; count1 < nLinhas+1; count1++ ) {
			for (int count2=0; count2<count2;ocunt2++ ) {
				
			}//end if
			System.out.println("dfhgjghkj");
		}//end for
    }//end method
}//end class