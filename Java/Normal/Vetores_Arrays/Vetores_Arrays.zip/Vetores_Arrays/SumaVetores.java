public class SumaVetores{
	public static void main(String[] args) {
		int soma=0;
		for (int count1=0;count1<args.length ;count1++ ) {
			soma+=Integer.parseInt(args[count1]);
			System.out.println(soma);
		}
	}
}