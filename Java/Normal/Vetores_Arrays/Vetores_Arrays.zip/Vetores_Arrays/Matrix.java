import java.util.Arrays;
public class Matrix{
	public static void main(String[] args) {

		/*String [][] matrix={
							{"a","b"},
							{"c","d"}
							};//end array
		System.out.println(matrix[1][0]);*/

		int [][] matrix = new int[3][];

		/*for (int i=0;i<matrix.length;i++ ) {
			matrix[i][0]="a";
		}*/

		/*[0][0]="1";
		matrix[1][0]="1";
		matrix[1][1]="2";
		matrix[2][0]="1";
		matrix[2][1]="2";
		matrix[2][2]="3";

		System.out.println(matrix[0][0]);
		System.out.print(matrix[1][0]);
		System.out.println(matrix[1][1]);
		System.out.print(matrix[2][0]);
		System.out.print(matrix[2][1]);
		System.out.println(matrix[2][2]);*/

		for (int count1=0; count1 < matrix.length; count1++ ) {
			matrix[count1] = new int [count1 + 1]; 
			for (int count2 = 0; count2 <= count1; count2++ ) {
				matrix[count1][count2] = count2+1; 
			}//end for
		}//end for

		for (int count1=0; count1 < matrix.length; count1++) {
			System.out.println(Arrays.toString(matrix[count1]));
		}//end for
	}//end method
}//end class