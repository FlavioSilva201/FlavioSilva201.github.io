public class VetoresDoAveco{
	public static void main(String[] args) {

		int [] vetor = new int[] {1,2,3,4,5};
		int temporal=0;
		int count2=vetor.length-1;
		/*while (count<vetor.legth){
			
		}*/// end while
		for (int count=0;count<vetor.length/2;count++) {
			temporal=vetor[count];
			vetor[count]=vetor[count2];
			vetor[count2]=temporal;
			count2--;
		}// end for
		for (int count3=0;count3<vetor.length ;count3++ ) {
			System.out.println(vetor[count3]);
		}// End for
	}// end method
}//end class