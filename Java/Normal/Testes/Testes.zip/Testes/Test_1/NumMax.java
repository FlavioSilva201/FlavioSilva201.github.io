public class NumMax{ //Clia uma class
	public static void main(String [] args) {//Inicia o Method
		int maiorNumero=0;//Cria uma variavel inteira "maiorNumero" com o valor de 0
		for (int count1=1;count1<args.length;count1++) { //inicia o ciclo que acaba no número de args selecionados
			if (maiorNumero<Integer.parseInt(args[count1])){//se o número do vetor "args" for maior que o maiorNumero então
				maiorNumero=Integer.parseInt(args[count1]);//este número passa a ser o maior e a variavel é atualizada
			}//end if
			//System.out.println(args[count1]);
		}//end for
		System.out.println(maiorNumero); //escreve o maior número
	}// end method
}//end class