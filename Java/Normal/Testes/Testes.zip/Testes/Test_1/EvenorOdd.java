public class EvenorOdd{ // Cria uma class
	public static void main(String[] args) { // inicia o method
		int num1=Integer.parseInt(args[0]);//recolhe o primeiro argumento ao iniciar o programa incerindo-o em uma variavel
		if (num1%2==1) { // se o resto da divisão do número escolhido pelo utilizador foi 0 então
			System.out.println("Is Odd");// escreve impar
		} else{// se não
			System.out.println("Even"); //escreve par
		}//end else
	}// end method
}//end class