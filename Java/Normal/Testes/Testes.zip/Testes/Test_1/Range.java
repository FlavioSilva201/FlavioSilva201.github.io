public class Range{ //Cria uma classe
	public static void main(String[] args) { //Inicia o Method
		int menor = Integer.parseInt(args[0]);//recebe o primeiro argomento como inteiro na variavel menor
		int maior = Integer.parseInt(args[1]);//recebe o segundo argomento como um número inteiro na variavel maior
		int num3=maior-menor;//Cria uma variavel "num3" e faz a subtração da variavel maior com a menor

		for (int count1=0; count1<=num3; ++count1 ) { //inicia um ciclo com a criação de uma variavel e diz que ele só ira acabar quando o número de repetições for igual a variavel num3
			System.out.println(menor+count1);//escreve a soma do número mais pequeno com o número de repetições
		}//end for
	}//end method
}//end class