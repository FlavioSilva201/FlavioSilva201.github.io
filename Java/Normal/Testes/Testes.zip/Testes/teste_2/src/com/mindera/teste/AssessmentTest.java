package com.mindera.teste;

public class AssessmentTest {
    public static void main(String[] args) {
        String nome = "João";
        metodo(nome);
        System.out.println(nome);
        System.out.println("Média: " + avg(new double [] {1, 2, 3, 4}));
        System.out.println("Será? " + requireRange(0,20,21));
        System.out.println("Passas-te de ano? " + hasfailed());
    }

    public static void metodo(String nome){
        nome = "Manel";
        System.out.println(nome);
    }

    public static double avg(double [] numeros){
        double media=0;
        for (int count1=0; count1 < numeros.length; count1++){
            media+=numeros[count1];
        }
        media = media / numeros.length;
        return media;
    }

    public static boolean requireRange(double lower, double upper, double value){
        return ((lower < value) && (upper > value));
    }

    public static boolean hasfailed(){
        return requireRange(9.5,20, avg(new double[] {9.3, 9.4, 30, 8}));
    }
}
