package com.mindera.school.Funcoes.Funcoes;

public class funcoes_subRotinas{
	public static void main(String[] args) {
		System.out.println("Hello World");
		printHollaMundo();
		
		int num1=2 , num2=3;
		int soma = add(num1 , num2);
		System.out.println(soma);
	}//end method main

	public static void printHollaMundo(){
		System.out.println("Holla Mundo");
	}//end method printHollaMundo

	public static int add(int num1, int num2){
		return num1 + num2;
	}//end method add
}//end class