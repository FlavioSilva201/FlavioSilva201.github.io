package com.mindera.school.Funcoes.Funcoes;

public class funcoes_sqrt{
	public static void main(String[] args) {
		System.out.println("SQRT");
		System.out.println("Vou resolver");

		int num1 = 64;
		double numQuadrado = quadrado(num1);
		System.out.println(numQuadrado);
		System.out.println("Resolvido");
	}//end method -> main

	public static double quadrado(double num1) {
		return Math.sqrt(num1);
	}//end method -> quadrado


}//end class funcoes