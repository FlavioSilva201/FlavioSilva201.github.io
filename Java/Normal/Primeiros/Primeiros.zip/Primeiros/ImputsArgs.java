public class ImputsArgs{
    public static void main(String[] args) {
        System.out.println("Hello " + args[0]+args[1]+args[2]);
        System.out.println("Pint");
        
    }
}
