public class SequenciaFibonacci{
	public static void main(String[] args) {
		int num1=0;
		int num2=1;

		/*for (int count2=2; count2<=11; count2++) {
			num2=num2+num1;
			num1=num2-num1;
			System.out.println(num2);
		}*/

		/*for (int count1=1;count1<=10 ;count1++ ) {
			if (num1>num2) {
				num2=num2+num1;
				System.out.println(num2);
			}else{
				num1=num1+num2;
				System.out.println(num1);
			}
		}*/
		
		do{
			System.out.println(num2);
			num2=num2+num1;
			num1=num2-num1;
		}while (num2<=100);
	}
}