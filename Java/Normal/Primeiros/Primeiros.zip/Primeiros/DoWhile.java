public class DoWhile{
	public static void main(String[] args) {
		int num1=0;
		int num2=1;

		do{
			System.out.println(num2);
			num2=num2+num1;
			num1=num2-num1;
		}while (num2<=100);
	}
}