public class For{
	public static void main(String[] args) {
		for (int x=0; x<1000000 ;x++) {
			if (x==3) {
				System.out.println(x + " Hey!!!!!!!!!!!!!");
				continue;
			}
			else{
				System.out.println(x);
			}
		}
	}
}