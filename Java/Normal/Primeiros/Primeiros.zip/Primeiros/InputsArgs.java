 public class InputsArgs{
 	public static void main(String[] args) {
    	int num1 = Integer.parseInt(args[0]);
    	System.out.println("Disses-te: " + num1);
	}
}