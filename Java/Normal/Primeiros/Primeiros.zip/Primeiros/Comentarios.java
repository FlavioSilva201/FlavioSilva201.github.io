public class Comentarios{
	public static void main(String[] args) {
		System.out.println("Comentários -> ver no código"); //Comentário de uma linha
		/*Comentário
		De
		Varias
		Linhas */

		/**
		Comentário de Decumentação
		*/
	}
}