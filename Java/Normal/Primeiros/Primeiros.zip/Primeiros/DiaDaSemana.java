import java.util.Scanner; // importar a biblioteca Scanner 

public class DiaDaSemana {
    public static void main(String[] args) { 
        Scanner receber = new Scanner(System.in);

        System.out.println("Insere o dia: ");
        //int dia = Integer.parseInt(args[0]);
        int dia = receber.nextInt();

        System.out.println("Insere o mês: ");
        //int mes = Integer.parseInt(args[1]);
        int mes = receber.nextInt();

        System.out.println("Insere o ano: ");
        //int ano = Integer.parseInt(args[2]);
        int ano = receber.nextInt();

//-----------------Cena das Contas------------
        int ano0 = ano - (14 - mes) / 12;
        int num1 = ano0 + ano0/4 - ano0/100 + ano0/400;
        int mes0 = mes + 12 * ((14 - mes) / 12) - 2;
        int diaD = (dia + num1 + (31*mes0)/12) % 7;



//-----------------Mês------------
        String mesTexto;
    if (mes==1) {  
        mesTexto="Janeiro";
    }
    else if (mes==2){
        mesTexto="Fevereiro";
    }
    else if (mes==3){
        mesTexto="Março";
    }
    else if (mes==4){
        mesTexto="Abril";
    }
    else if (mes==5){
        mesTexto="Maio";
    }
    else if (mes==6){
        mesTexto="Junho";
    }
    else if (mes==7){
        mesTexto="Julho";
    }
    else if (mes==8){
        mesTexto="Agosto";
    }
    else if (mes==9){
        mesTexto="Setembro";
    }
    else if (mes==10){
        mesTexto="Outubro";
    }
    else if (mes==11){
        mesTexto="Novembro";
    }
    else if (mes==12){
        mesTexto="Dezembro";
    }
    else{
        mesTexto="Erro";
    }

//-----------------Resposta------------
    if (diaD==1) {
    System.out.println("Este dia calha a uma Segunda-feira!  - " + " Dia: " + dia + " Mês: " + mes + "/" + mesTexto + " Ano: " + ano);   
    }
    else if (diaD==2){
    System.out.println("Este dia calha a uma Terça-feira!  - " + " Dia: " + dia + " Mês: " + mes + "/" + mesTexto + " Ano: " + ano);
    }
    else if (diaD==3){
    System.out.println("Este dia calha a uma Quarta-feira!  - " + " Dia: " + dia + " Mês: " + mes + "/" + mesTexto + " Ano: " + ano);
    }
    else if (diaD==4){
    System.out.println("Este dia calha a uma Quinta-feira!  - " + " Dia: " + dia + " Mês: " + mes + "/" + mesTexto + " Ano: " + ano);
    }
    else if (diaD==5){
    System.out.println("Este dia calha a uma Sexta-feira!  - " + " Dia: " + dia + " Mês: " + mes + "/" + mesTexto + " Ano: " + ano);
    }
    else if (diaD==6){
    System.out.println("Este dia calha o um Sabado!  - " + " Dia: " + dia + " Mês: " + mes + "/" + mesTexto + " Ano: " + ano);
    }
    else{
    System.out.println("Este dia calha a um Domingo!  - " + " Dia: " + dia + " Mês: " + mes + "/" + mesTexto + " Ano: " + ano);
    }
}

}