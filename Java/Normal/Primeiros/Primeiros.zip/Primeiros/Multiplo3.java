public class Multiplo3{
	public static void main(String[] args) {
		int num1 =Integer.parseInt(args[0]);
		int resp=num1%3;

		//Com If

		//if (resp==0){
		//	System.out.println("É múltiplo");
		//}
		//else{
		//System.out.println("Não é multiplo");
		//}

		//Com Boolean
		
		boolean resto=(num1%3==0);
		System.out.println(resto);
	}
}