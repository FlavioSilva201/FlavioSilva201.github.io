public class LimiteJava{
	public static void main(String[] args) {

		long num1=1 000 000 000;

		for (int count = 0; count < num1; count++ ) {
   			System.out.println(count);
		}
	}
}