public class ImputsArgsString{
    public static void main(String[] args) {
        String palavra=args[0];
        System.out.println(palavra);
    }
}