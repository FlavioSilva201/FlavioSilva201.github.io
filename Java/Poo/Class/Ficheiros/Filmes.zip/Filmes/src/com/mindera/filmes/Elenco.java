package com.mindera.filmes;

public class Elenco {
    Papel[] p = new Papel[10];
}
