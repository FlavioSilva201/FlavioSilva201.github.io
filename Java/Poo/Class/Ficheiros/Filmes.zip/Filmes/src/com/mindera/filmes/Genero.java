package com.mindera.filmes;

public class Genero {
    String generoFilme;
}
