package com.mindera.filmes;

public class FilmesApp {
    public static void main(String[] args) {

    }
}
