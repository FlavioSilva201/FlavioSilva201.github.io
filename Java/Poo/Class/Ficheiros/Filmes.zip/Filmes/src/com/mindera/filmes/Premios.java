package com.mindera.filmes;

public class Premios {
    String nomePremio;
}
