package com.mindera.filmes;

public class Papel {
    Personagem p;
    Ator a;
}
