package com.mindera.salaappp;

import java.util.ArrayList;

public class index {

    public static void main(String[] args) {

        /*
        Sala sala = new Sala();
        Aluno aluno1 = new Aluno(1, 20, "Tiago");
        Aluno aluno2 = new Aluno(2, 23, "Zé");
        Aluno aluno3 = new Aluno(3, 212, "António");

        Sala.addStudent(aluno1);
        Sala.addStudent(aluno2);
        Sala.addStudent(aluno3);

        System.out.println(aluno1);
        System.out.println(aluno2);
        System.out.println(aluno3);

        */

        ArrayList aluno = new ArrayList();
        aluno.add(new Aluno(4, 212, "Atfuskf"));
        Aluno a = (Aluno) aluno.get(0);
        //Aluno a = aluno.get(0);
        System.out.println(a);
        

/*
        ArrayList strings = new ArrayList();
        strings.add("valor");
        strings.add(new Integer(1));
        String a = (String) strings.get(0);
        String i = (String) strings.get(1);
        System.out.println(a);
        System.out.println(i);

 */
    }
}
