package com.mindera.salaappp;

public class Professor {

        int prof_id;
        int idade;
        String nome;
        String disciplina;
}
