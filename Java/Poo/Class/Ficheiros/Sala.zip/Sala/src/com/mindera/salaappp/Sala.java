package com.mindera.salaappp;

public class Sala {

    public static int countAluno = 0;

    private static Aluno[] alunos = new Aluno[9];
    // Professor[] stores = new Professor[10];

    public static void addStudent(Aluno aluno) {
        alunos[countAluno] = aluno;
        countAluno++;
    }

}
